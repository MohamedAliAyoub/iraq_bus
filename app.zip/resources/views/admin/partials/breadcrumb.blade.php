

<div class="row align-items-center mb-30 justify-content-between">
    <div class="col-lg-3 col-sm-3">
        <h6 class="page-title">{{ __($pageTitle) }}</h6>
    </div>
    <div class="col-lg-9 col-sm-9 text-sm-right mt-sm-0 mt-3 right-part">
        @stack('breadcrumb-plugins')
    </div>
</div>
