<?php $__env->startSection('content'); ?>
<div class="container padding-top padding-bottom">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-6">
            <div class="profile__content__edit p-0">
                <div class="title"><?php echo app('translator')->get('Please Verify Your Mobile to Get Access'); ?></div>
                <div class="p-4">
                    <form action="<?php echo e(route('user.verify.sms')); ?>" method="POST" class="login-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <p class="text-center"><?php echo app('translator')->get('Your Mobile Number'); ?>:  <strong><?php echo e(auth()->user()->mobile); ?></strong></p>
                        </div>

                        <div class="input-group">
                            <label for="code" class="form-label"><?php echo app('translator')->get('Verification Code'); ?></label>
                            <input type="text" class="form-contorl form--control radius-0" id="code" name="sms_verified_code">
                        </div>

                        <div class="col">
                            <button type="submit" class="btn btn--dark btn--block mt-3"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>

                        <div class="form-group">
                            <small><?php echo app('translator')->get('If you don\'t get any code'); ?>, <a href="<?php echo e(route('user.send.verify.code')); ?>?type=phone" class="forget-pass"> <?php echo app('translator')->get('Try again'); ?></a></small>
                            <?php if($errors->has('resend')): ?>
                                <br/>
                                <small class="text-danger"><?php echo e($errors->first('resend')); ?></small>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict";
        $('#code').on('input change', function () {
          var xx = document.getElementById('code').value;
          $(this).val(function (index, value) {
             value = value.substr(0,7);
              return value.replace(/\W/gi, '').replace(/(.{3})/g, '$1 ');
          });
      });
    })(jQuery)
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/busiraq/public_html/core/resources/views/templates/basic/user/auth/authorization/sms.blade.php ENDPATH**/ ?>