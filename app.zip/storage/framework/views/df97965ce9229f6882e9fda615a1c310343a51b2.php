<?php
$content = getContent('contact.content', true);
?>
<!-- Header Section Starts Here -->
<div class="header-top">
    <div class="container">
        <div class="header-top-area">
            <ul class="left-content">
                <li>
                    <i class="las la-phone"></i>
                    <a href="tel:<?php echo e(__(@$content->data_values->contact_number)); ?>">
                        <?php echo e(__(@$content->data_values->contact_number)); ?>

                    </a>
                </li>
                <li>
                    <i class="las la-envelope-open"></i>
                    <a href="mailto:<?php echo e(__(@$content->data_values->email)); ?>">
                        <?php echo e(__(@$content->data_values->email)); ?>

                    </a>
                </li>
            </ul>
            <div class="right-content">
                <div>
                    <select class="langSel form--control">
                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code); ?>" <?php if(session('lang')==$item->code): ?> selected <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="header-bottom">
    <div class="container">
        <div class="header-bottom-area">
            <div class="logo">
                <a href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'].'/logo.png')); ?>" alt="<?php echo app('translator')->get('Logo'); ?>">
                </a>
            </div> <!-- Logo End -->
            <ul class="menu">
                <li>
                    <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
                </li>
                <li>
                    <a href="javascript::void()"><?php echo app('translator')->get('Booking'); ?></a>
                    <ul class="sub-menu">
                        <li>
                            <a href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Buy Ticket'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.ticket.history')); ?>"><?php echo app('translator')->get('Booking History'); ?></a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="javascript::void()"><?php echo app('translator')->get('Support Ticket'); ?></a>
                    <ul class="sub-menu">
                        <li>
                            <a href="<?php echo e(route('ticket.open')); ?>"><?php echo app('translator')->get('Create New'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('support_ticket')); ?>"><?php echo app('translator')->get('Tickets'); ?></a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#0"><?php echo app('translator')->get('Profile'); ?></a>
                    <ul class="sub-menu">
                        <li>
                            <a href="<?php echo e(route('user.profile.setting')); ?>"><?php echo app('translator')->get('Profile'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.change.password')); ?>"><?php echo app('translator')->get('Change Password'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.logout')); ?>"><?php echo app('translator')->get('Logout'); ?></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <div class="d-flex flex-wrap algin-items-center">
                <a href="<?php echo e(route('ticket')); ?>" class="cmn--btn btn--sm"><?php echo app('translator')->get('Buy Tickets'); ?></a>
                <div class="header-trigger-wrapper d-flex d-lg-none ms-4">
                    <div class="header-trigger d-block d-lg-none">
                        <span></span>
                    </div>
                    <div class="top-bar-trigger">
                        <i class="las la-ellipsis-v"></i>
                    </div>
                </div><!-- Trigger End-->
            </div>
        </div>
    </div>
</div>
<!-- Header Section Ends Here -->

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        "use strict";
        $(".langSel").on("change", function() {
            window.location.href = "<?php echo e(route('home')); ?>/change/" + $(this).val();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/busiraq/public_html/core/resources/views/templates/basic/partials/user_header.blade.php ENDPATH**/ ?>