<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /home/busiraq/public_html/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>