<?php $__env->startSection('content'); ?>
<?php
$content = getContent('sign_up.content', true);
?>
<!-- Account Section Starts Here -->
<section class="account-section bg_img" style="background: url(<?php echo e(getImage('assets/images/frontend/sign_up/'. @$content->data_values->background_image, "1920x1280")); ?>) bottom left;">
    <span class="spark"></span>
    <span class="spark2"></span>
    <div class="account-wrapper  sign-up">
        <div class="account-form-wrapper">
            <div class="account-header">
                <div class="left-content">
                    <div class="logo mb-4">
                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'].'/logo.png')); ?>" alt="Logo"></a>
                    </div>
                    <h3 class="title"><?php echo e(__(@$content->data_values->heading)); ?></h3>
                    <span><?php echo e(__(@$content->data_values->sub_heading)); ?></span>
                </div>
            </div>
            <form class="account-form row" action="<?php echo e(route('user.register')); ?>" method="POST" onsubmit="return submitUserForm();">
                <?php echo csrf_field(); ?>

                <div class="col-sm-6 col-xl-6">
                    <div class="form--group">
                        <label for="firstname"><?php echo app('translator')->get('First Name'); ?> <span>*</span></label>
                        <input id="firstname" type="text" class="form--control" name="firstname" value="<?php echo e(old('firstname')); ?>" placeholder="<?php echo app('translator')->get('Enter Your First Name'); ?>" required>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-6">
                    <div class="form--group">
                        <label for="lastname"><?php echo app('translator')->get('Last Name'); ?> <span>*</span></label>
                        <input id="lastname" type="text" class="form--control" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="<?php echo app('translator')->get('Enter Your Last Name'); ?>" required>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-6">
                    <div class="form--group">
                        <label for="country"><?php echo app('translator')->get('Country'); ?></label>
                        <select name="country" id="country" class="form--control">
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" data-code="<?php echo e($key); ?>"><?php echo e(__($country->country)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>


                <div class="col-sm-6 col-xl-6">
                    <label for="mobile"><?php echo app('translator')->get('Mobile'); ?> <span>*</span></label>
                    <div class="form--group">
                        <div class="input-group flex-nowrap">
                                <span class="input-group-text mobile-code border-0 h-40"></span>
                                <input type="hidden" name="mobile_code">
                                <input type="hidden" name="country_code">
                            <input type="number" name="mobile" id="mobile" value="<?php echo e(old('mobile')); ?>" class="form--control ps-2  checkUser" placeholder="<?php echo app('translator')->get('Your Phone Number'); ?>">
                        </div>
                        <small class="text-danger mobileExist"></small>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-6">
                    <div class="form--group">
                        <label for="username"><?php echo app('translator')->get('Username'); ?> <span>*</span></label>
                        <input id="username" type="text" class="form--control checkUser" name="username" value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Enter Username'); ?>" required>
                        <small class="text-danger usernameExist"></small>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-6">
                    <div class="form--group">
                        <label for="email"><?php echo app('translator')->get('Email'); ?> <span>*</span></label>
                        <input id="email" type="email" class="form--control checkUser" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('Enter Your Email'); ?>" required>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-6 hover-input-popup">
                    <div class="form--group">
                        <label for="password"><?php echo app('translator')->get('Password'); ?> <span>*</span></label>
                        <input id="password" type="password" class="form--control" name="password" placeholder="<?php echo app('translator')->get('Enter Your Password'); ?>" required>
                        <?php if($general->secure_password): ?>
                            <div class="input-popup">
                                <p class="error lower"><?php echo app('translator')->get('1 small letter minimum'); ?></p>
                                <p class="error capital"><?php echo app('translator')->get('1 capital letter minimum'); ?></p>
                                <p class="error number"><?php echo app('translator')->get('1 number minimum'); ?></p>
                                <p class="error special"><?php echo app('translator')->get('1 special character minimum'); ?></p>
                                <p class="error minimum"><?php echo app('translator')->get('6 character password'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-6">
                    <div class="form--group">
                        <label for="password-confirm"><?php echo app('translator')->get('Confirm Password'); ?> <span>*</span></label>
                        <input id="password-confirm" type="password" class="form--control" name="password_confirmation" placeholder="<?php echo app('translator')->get('Confirm Password'); ?>" required>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-6 mb-3">
                    <?php echo loadReCaptcha() ?>
                </div>
                <?php echo $__env->make($activeTemplate.'partials.custom_captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php if($general->agree): ?>
                <div class="col-sm-6 col-xl-6">
                    <div class="form--group custom--checkbox">
                        <input type="checkbox"  name="agree" id="agree">
                        <label for="agree"><?php echo app('translator')->get('Accepting all'); ?> &nbsp;</label>
                        <?php
                            $policies = getContent('policies.element',null,3);
                        ?>
                        <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('policy.details', [$policy->id, slug($policy->data_values->title)])); ?>"><?php
                                echo $policy->data_values->title
                            ?> </a> <?php if(!$loop->last): ?> , <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="col-md-12">
                    <div class="form--group">
                        <button class="account-button w-100"><?php echo app('translator')->get('Sign Up'); ?></button>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="account-page-link">
                        <p><?php echo app('translator')->get('Already have an Account?'); ?> <a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Sign In'); ?></a></p>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- Account Section Ends Here -->

<div class="modal fade" id="existModalCenter" tabindex="-1" role="dialog" aria-labelledby="existModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"  id="existModalLongTitle"><?php echo app('translator')->get('You are with us'); ?></h5>
                <button type="button" class="w-auto btn--close" data-bs-dismiss="modal"><i class="las la-times"></i></button>
            </div>
            <div class="modal-body">
                <strong class="text-dark"><?php echo app('translator')->get('You already have an account please Sign in '); ?></strong>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn--danger btn--sm w-auto" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                <a href="<?php echo e(route('user.login')); ?>" class="btn btn--success btn--sm w-auto"><?php echo app('translator')->get('Login'); ?></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .hover-input-popup {
            position: relative;
        }
        .hover-input-popup:hover .input-popup {
            opacity: 1;
            visibility: visible;
        }
        .input-popup {
            position: absolute;
            bottom: 130%;
            left: 50%;
            width: 280px;
            background-color: #1a1a1a;
            color: #fff;
            padding: 20px;
            border-radius: 5px;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%);
            opacity: 0;
            visibility: hidden;
            -webkit-transition: all 0.3s;
            -o-transition: all 0.3s;
            transition: all 0.3s;
        }
        .input-popup::after {
            position: absolute;
            content: '';
            bottom: -19px;
            left: 50%;
            margin-left: -5px;
            border-width: 10px 10px 10px 10px;
            border-style: solid;
            border-color: transparent transparent #1a1a1a transparent;
            -webkit-transform: rotate(180deg);
            -ms-transform: rotate(180deg);
            transform: rotate(180deg);
        }
        .input-popup p {
            padding-left: 20px;
            position: relative;
        }
        .input-popup p::before {
            position: absolute;
            content: '';
            font-family: 'Line Awesome Free';
            font-weight: 900;
            left: 0;
            top: 4px;
            line-height: 1;
            font-size: 18px;
        }
        .input-popup p.error {
            text-decoration: line-through;
        }
        .input-popup p.error::before {
            content: "\f057";
            color: #ea5455;
        }
        .input-popup p.success::before {
            content: "\f058";
            color: #28c76f;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span class="text-danger"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }
        (function ($) {
            <?php if($mobile_code): ?>
            $(`option[data-code=<?php echo e($mobile_code); ?>]`).attr('selected','');
            <?php endif; ?>

            $('select[name=country]').change(function(){
                $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
                $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
                $('.mobile-code').text('+'+$('select[name=country] :selected').data('mobile_code'));
            });
            $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
            $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
            $('.mobile-code').text('+'+$('select[name=country] :selected').data('mobile_code'));
            <?php if($general->secure_password): ?>
                $('input[name=password]').on('input',function(){
                    secure_password($(this));
                });
            <?php endif; ?>

            $('.checkUser').on('focusout',function(e){
                var url = '<?php echo e(route('user.checkUser')); ?>';
                var value = $(this).val();
                var token = '<?php echo e(csrf_token()); ?>';
                if ($(this).attr('name') == 'mobile') {
                    var mobile = `${$('.mobile-code').text().substr(1)}${value}`;
                    var data = {mobile:mobile,_token:token}
                }
                if ($(this).attr('name') == 'email') {
                    var data = {email:value,_token:token}
                }
                if ($(this).attr('name') == 'username') {
                    var data = {username:value,_token:token}
                }
                $.post(url,data,function(response) {
                    if (response['data'] && response['type'] == 'email') {
                    $('#existModalCenter').modal('show');
                    }else if(response['data'] != null){
                    $(`.${response['type']}Exist`).text(`${response['type']} already exist`);
                    }else{
                    $(`.${response['type']}Exist`).text('');
                    }
                });
            });

        })(jQuery);

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.authenticate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/busiraq/public_html/core/resources/views/templates/basic/user/auth/register.blade.php ENDPATH**/ ?>